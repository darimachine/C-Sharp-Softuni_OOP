﻿using System;
using System.Collections.Generic;

namespace Animals
{
    class Animal
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public Animal()
        {

        }
        public Animal(string name, int age,string gender)
        {
            this.Name = name;
            this.Age = age;
            this.Gender = gender;
        }
        public string Gender { get; set; }
        public virtual void ProduceSound()
        {

        }
        
    }
    class Dog : Animal
    {
        public Dog(string name, int age, string gender) : base(name, age, gender)
        {
        }

        public override void ProduceSound()
        {
            Console.WriteLine("Woof!");
        }
    }
    class Frog : Animal
    {
        public Frog(string name, int age, string gender) : base(name, age, gender)
        {
        }

        public override void ProduceSound()
        {
            Console.WriteLine("Ribbit");
        }
    }
    class Cat : Animal
    {
        public Cat(string name, int age, string gender) : base(name, age, gender)
        {
        }

        public override void ProduceSound()
        {
            Console.WriteLine("meow meow");
        }
    }
    class Kitten : Cat
    {
        public Kitten(string name, int age, string gender) : base(name, age, gender)
        {
        }

        public override void ProduceSound()
        {
            Console.WriteLine("Meow");
        }
    }
    class TomCat : Cat
    {
        public TomCat(string name, int age, string gender) : base(name, age, gender)
        {
        }

        public override void ProduceSound()
        {
            Console.WriteLine("MEOW");
        }
    }
    public class StartUp
    {
        static void Main(string[] args)
        {
            string command = Console.ReadLine();
            Animal animal = new Animal();
            List<Animal> animals = new List<Animal>();
            while (command != "Beast!")
            {
                var lines = Console.ReadLine().Split(" ");
                
                if (command == "Cat")
                {
                    
                    if(lines[2] == "Male")
                    {
                        animal = new TomCat(lines[0], int.Parse(lines[1]), lines[2]);
                    }
                    else
                    {
                        animal = new Kitten(lines[0], int.Parse(lines[1]), lines[2]);
                    }
                }
                else if (command == "Dog")
                {
                    
                    animal = new Dog(lines[0], int.Parse(lines[1]), lines[2]);
       
                }
                else if (command == "Frog")
                {
                    animal = new Frog(lines[0], int.Parse(lines[1]), lines[2]);
                }
                animals.Add(animal);

                command = Console.ReadLine();
                
                
            }
            foreach (var item in animals)
            {
                if (item.Age > 0)
                {
                    Console.WriteLine(item.GetType().ToString().Split(".")[1]);
                    Console.WriteLine($"{item.Name} {item.Age} {item.Gender}");
                    item.ProduceSound();
                }
                else
                {
                    Console.WriteLine("Invalid input!");
                }
                
            }
            
        }
    }
}
