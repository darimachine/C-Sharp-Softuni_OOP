﻿namespace Players_Monsters
{
    class Knight : Hero
    {
        public Knight(string username, int level) : base(username, level)
        {
        }
    }
}
