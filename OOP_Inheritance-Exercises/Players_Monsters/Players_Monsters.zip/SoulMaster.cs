﻿namespace Players_Monsters
{
    class SoulMaster : DarkWizard
    {
        public SoulMaster(string username, int level) : base(username, level)
        {
        }
    }
}
