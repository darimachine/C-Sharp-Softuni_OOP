﻿namespace Players_Monsters
{
    class MuseElf : Elf
    {
        public MuseElf(string username, int level) : base(username, level)
        {
        }
    }
}
